package com.ticket.MovieTicket.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ticket.MovieTicket.Dao.BookingDao;
import com.ticket.MovieTicket.Dao.ShowDao;
import com.ticket.MovieTicket.Dao.TheaterDao;
import com.ticket.MovieTicket.dto.BookingDto;
import com.ticket.MovieTicket.dto.TheaterDto;
import com.ticket.MovieTicket.model.Booking;
import com.ticket.MovieTicket.model.Show;
import com.ticket.MovieTicket.model.Theater;

@Service
public class BookingService {
	@Autowired
	BookingDao bookingDao;

	@Autowired
	TheaterDao theaterDao;
	@Autowired
	ShowDao showDao;

	// Setting Booking Information
	public Booking saveBooking(String movieName, String theaterId, String showTime, String userId) {
		// TODO Auto-generated method stub
		Theater theater = theaterDao.findById(theaterId).orElse(null);
		Booking booking = new Booking();
		booking.setDate(LocalDate.now());
		booking.setMovieName(movieName);
		booking.setShowTime(showTime);
		booking.setTheaterName(theater.getTheaterName());
		booking.setUserId(userId);
		return bookingDao.save(booking);

	}
}
