package com.ticket.MovieTicket.Dao;


import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ticket.MovieTicket.model.Theater;



@Repository 
public interface TheaterDao  extends CrudRepository<Theater, String>{
//List<Theater> findByTheaterId(String movieName);
}
