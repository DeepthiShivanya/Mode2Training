package com.ticket.MovieTicket.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ticket.MovieTicket.Dao.TheaterDao;
import com.ticket.MovieTicket.model.Theater;

@Service
public class TheaterService {
	@Autowired
	TheaterDao theaterDao;

	// Adding Theater Information
	public String addTheater(Theater theater) {
		theater.setTheaterId(theater.getTheaterId());
		theater.setTheaterName(theater.getTheaterName());
		theater.setPlace(theater.getPlace());
		theaterDao.save(theater);
		return "theater details added";
	}

	// Iterating The TheaterDto Class
	public Iterable<Theater> findTheater() {
		// TODO Auto-generated method stub
		Iterable<Theater> list = theaterDao.findAll();
		return list;
	}

}
