package com.streamexamples;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StreamExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> list = Arrays.asList("siya", "jiya", "niya", "piya", "siya");

		// using peek() method
		List<String> newList = list.stream().peek(System.out::println).collect(Collectors.toList());
		System.out.println("using peek() method:" + newList);

		// Get collection without duplicate i.e. distinct only
		List<String> distinctElements = list.stream().distinct().collect(Collectors.toList());
		// Let's verify distinct elements
		System.out.println("using distinct method:" + distinctElements);

		// using flatMap() method
		List<String> list1 = Arrays.asList("geetha", "seetha");
		List<String> list2 = Arrays.asList("sona", "mona");
		List<List<String>> addlist = Arrays.asList(list, list1, list2);
		List<String> listing = addlist.stream().flatMap(x -> x.stream()).collect(Collectors.toList());
		System.out.println("using flatMap() method:" + listing);

		// using toArray() method
		Object[] arr = list.toArray();
		System.out.println("Elements of ArrayList as Array: " + Arrays.toString(arr));

		List<Student> stud = new ArrayList<Student>();
		stud.add(new Student(1, "siya", 98));
		stud.add(new Student(2, "jiya", 88));
		stud.add(new Student(3, "piya", 75));
		stud.add(new Student(4, "niya", 67));
		stud.add(new Student(5, "kiya", 54));
		stud.add(new Student(6, "diya", 40));

		// count number of Students based on the filter
		long count = stud.stream().filter(student -> student.score < 60).count();
		System.out.println("Number of count:" + count);

		// min() method to get min student score
		Student studentB = stud.stream().min((student1, student2) -> student1.score > student2.score ? 1 : -1).get();
		System.out.println("minimum score:" + studentB.score);

		// min() method to get min student score using max()
		Student studentB1 = stud.stream().max((student1, student2) -> student1.score < student2.score ? 1 : -1).get();
		System.out.println("minimum score:" + studentB1.score);

		// max() method to get max student score
		Student studentA = stud.stream().max((student1, student2) -> student1.score > student2.score ? 1 : -1).get();
		System.out.println("maximum score:" + studentA.score);

		// using reduce() method
		Object totalscore = stud.stream().map(student -> student.score).reduce((sum, score) -> sum + score); // accumulating score
		System.out.println("Using reduce method:" + totalscore);

		// using anyMatch() method
		boolean matched = stud.stream().anyMatch((s) -> s.name.startsWith("s"));
		System.out.println("using anyMatch:" + matched);

	}
}
