package com.streamexamples;

public class Student {
	public int rollnum;
	public String name;
	public int score;

	public int getRollnum() {
		return rollnum;
	}

	public void setRollnum(int rollnum) {
		this.rollnum = rollnum;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public Student(int rollnum, String name, int score) {
		this.rollnum = rollnum;
		this.name = name;
		this.score = score;
	}

}
