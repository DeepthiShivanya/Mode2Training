package com.searchTrain.searchTrain.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.searchTrain.searchTrain.dao.PassengerDao;
import com.searchTrain.searchTrain.model.Passenger;

@Service
public class PassengerService {
	@Autowired
	PassengerDao passengerDao;
	public String addPassengerDetails(Passenger passenger)
	{
		passengerDao.save(passenger);
		return "passengerDetails Added successfully";
	}
	public List<Passenger> passengerDetails(String userId)
	{
		List<Passenger>list=passengerDao.passengerDetails(userId);
		return list;
	}
}
