package com.searchTrain.searchTrain.service;

import java.time.LocalDate;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.searchTrain.searchTrain.ExceptionHandling.TrainIdNotFoundException;
import com.searchTrain.searchTrain.ExceptionHandling.TrainsAreNotFoundException;
import com.searchTrain.searchTrain.dao.SearchTrainDao;
import com.searchTrain.searchTrain.dto.SearchTrainDto;
import com.searchTrain.searchTrain.model.SearchTrain;

@Service

public class SearchTrainService {
	@Autowired
	SearchTrainDao searchTrainDao;
	SearchTrain searchTrain = new SearchTrain();

	public SearchTrainDto findTrain(String fromPlace, String toPlace, LocalDate date) {
		Optional<SearchTrain> trainDetails = searchTrainDao.findTrain(fromPlace, toPlace, date);
		SearchTrainDto searchTrainDto=new SearchTrainDto();
		searchTrainDto.setTrainName(trainDetails.get().getTrainName());
		searchTrainDto.setTrainId(trainDetails.get().getTrainId());
		searchTrainDto.setFromPlace(trainDetails.get().getFromPlace());
		searchTrainDto.setToPlace(trainDetails.get().getToPlace());
		searchTrainDto.setDate(trainDetails.get().getDate());
		searchTrainDto.setCost(trainDetails.get().getCost());
		
		if (!trainDetails.isPresent()) {
			throw new TrainsAreNotFoundException("Train are not available for this date-"+date);
		} else {
			return searchTrainDto;
		}

		
	}

	public SearchTrainDto findByTrainId(Integer trainId) {

		Optional<SearchTrain> train = searchTrainDao.findById(trainId);
		SearchTrainDto searchTrainDto=new SearchTrainDto();
		searchTrainDto.setTrainName(train.get().getTrainName());
		searchTrainDto.setTrainId(train.get().getTrainId());
		searchTrainDto.setFromPlace(train.get().getFromPlace());
		searchTrainDto.setToPlace(train.get().getToPlace());
		searchTrainDto.setDate(train.get().getDate());
		searchTrainDto.setCost(train.get().getCost());
		
		if (!train.isPresent()) {
			throw new TrainIdNotFoundException("Sorry Train is Invalid" + "-trainId" + trainId);
		} else {
			return searchTrainDto;
		}

	}

}
