package com.bookticket.BookingTrainTicket.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bookticket.BookingTrainTicket.Model.PassengerDetails;
import com.bookticket.BookingTrainTicket.Service.PassengerService;

@RestController
public class PassengerController {
	
	@Autowired
	PassengerService passengerService;
	 @PostMapping(value="/user/add/passenger/{bookingId}") 
	 public List<PassengerDetails> addPassengerDetails(@RequestBody PassengerDetails[] passenger,@PathVariable("bookingId") String bookingId) {
		  List<PassengerDetails> passenger1= passengerService.addPassengerDetails(bookingId,passenger);
		  return passenger1;
		  }

	 @DeleteMapping(value = "user/ticket/cancelByPnr/{PNR}")
		public String cancellingTrainTicketByPnr(@PathVariable ("PNR") String PNR) {
			 passengerService.cancellingTrainTicketByPnr(PNR);
			 return "ticket cancelled successfully";
		}
}
