package com.bookticket.BookingTrainTicket.Dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.bookticket.BookingTrainTicket.Model.PassengerDetails;

@Repository
public interface PassengerDao extends CrudRepository<PassengerDetails,String> {

}
