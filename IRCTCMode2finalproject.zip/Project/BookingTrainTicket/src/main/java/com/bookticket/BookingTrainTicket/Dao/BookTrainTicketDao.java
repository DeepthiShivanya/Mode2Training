package com.bookticket.BookingTrainTicket.Dao;

import org.springframework.data.repository.CrudRepository;
import com.bookticket.BookingTrainTicket.Model.BookTrainTicket;

public interface BookTrainTicketDao extends CrudRepository<BookTrainTicket, String> {

}
