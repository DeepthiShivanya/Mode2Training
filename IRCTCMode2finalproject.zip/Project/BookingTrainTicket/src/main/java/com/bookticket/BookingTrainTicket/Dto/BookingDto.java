package com.bookticket.BookingTrainTicket.Dto;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class BookingDto {
	private String bookingId;
	private LocalDate date;
	private int noOftickets;
	private int trainId;
	private String userId;

	public String getBookingId() {
		return bookingId;
	}

	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public int getNoOftickets() {
		return noOftickets;
	}

	public void setNoOftickets(int noOftickets) {
		this.noOftickets = noOftickets;
	}

	public int getTrainId() {
		return trainId;
	}

	public void setTrainId(int trainId) {
		this.trainId = trainId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

}
