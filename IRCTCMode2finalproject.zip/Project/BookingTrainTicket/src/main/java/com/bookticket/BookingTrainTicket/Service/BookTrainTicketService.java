package com.bookticket.BookingTrainTicket.Service;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.bookticket.BookingTrainTicket.Dao.BookTrainTicketDao;
import com.bookticket.BookingTrainTicket.Dto.BookingDto;
import com.bookticket.BookingTrainTicket.Exception.BookingIdNotFoundException;
import com.bookticket.BookingTrainTicket.Exception.SeatsNotAvailableException;
import com.bookticket.BookingTrainTicket.Model.BookTrainTicket;

@Service
public class BookTrainTicketService {
	@Autowired
	BookTrainTicketDao bookingTrainTicketDao;
	int noOfSeats = 100;
	BookingDto bookingDto = new BookingDto();

	public BookingDto bookingTrainTicket(BookTrainTicket bookTrainTicket) {

		int noOfTickets = bookTrainTicket.getNoOftickets();
		if (noOfSeats < noOfTickets) {
			throw new SeatsNotAvailableException("seats not available");
		} else {
			int auto = (int) (Math.random() * 100 + 1);
			String bookingId = bookTrainTicket.getUserId() + auto;
			bookTrainTicket.setBookingId(bookingId);
			noOfSeats = 100 - noOfTickets;
			System.out.println("noOfSeats:" + noOfSeats);
			bookingDto.setBookingId(bookingId);
			bookingDto.setDate(bookTrainTicket.getDate());
			bookingDto.setTrainId(bookTrainTicket.getTrainId());
			bookingDto.setUserId(bookTrainTicket.getUserId());
			bookingDto.setNoOftickets(bookTrainTicket.getNoOftickets());

			bookingTrainTicketDao.save(bookTrainTicket);

			return bookingDto;

		}
	}

	public String cancellingTrainTicket(String bookingId) {
		Optional<BookTrainTicket> bookId = bookingTrainTicketDao.findById(bookingId);
		if (!bookId.isPresent()) {
			throw new BookingIdNotFoundException("Booking ID is Not Found");
		} else {

			bookingTrainTicketDao.deleteById(bookingId);
			return "ticket cancelled";
		}

	}
}
