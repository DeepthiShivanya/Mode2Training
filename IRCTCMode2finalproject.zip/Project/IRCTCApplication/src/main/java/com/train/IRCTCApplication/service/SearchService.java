package com.train.IRCTCApplication.service;

import java.time.LocalDate;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;


import com.train.IRCTCApplication.dto.SearchTrainDto;

@Service
public class SearchService {
	
	@Autowired
	RestTemplate restTemplate;

	public SearchTrainDto findTrain(String fromPlace, String toPlace, LocalDate date) {
		return restTemplate.getForObject("http://localhost:8092/search/train/{fromPlace}/{toPlace}/{date}",SearchTrainDto.class,fromPlace,toPlace,date);
	}

	public SearchTrainDto searchTrain(Integer trainId) {
		return restTemplate.getForObject("http://localhost:8092/search/get/train/{trainId}",SearchTrainDto.class,trainId);
	}

}
