package com.hcl.bank.DAO;

import com.hcl.model.Customer;

public interface CustomerDAO 
{
	public void saveDetails(Customer customer);
}
