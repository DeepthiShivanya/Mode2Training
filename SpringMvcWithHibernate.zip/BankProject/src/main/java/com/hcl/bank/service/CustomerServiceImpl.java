package com.hcl.bank.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.ComponentScan;
import com.hcl.bank.DAO.CustomerDAOImpl;
import com.hcl.model.Customer;

@ComponentScan("custService")
public class CustomerServiceImpl implements CustomerService 
{

	@Autowired
	@Qualifier("customerDAO")
	CustomerDAOImpl customerDAO;
	@Override
	public void saveDetails(Customer customer) {
		// TODO Auto-generated method stub
		customerDAO.saveDetails(customer);
	}

	
}
