package com.hcl.bank.service;

import com.hcl.model.Customer;

public interface CustomerService 
{
	public void saveDetails(Customer custmer);
	
}
