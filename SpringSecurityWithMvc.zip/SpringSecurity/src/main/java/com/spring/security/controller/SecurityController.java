package com.spring.security.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class SecurityController {

	@RequestMapping(value="/enter/user", method = RequestMethod.GET)
	public String enterUser() {
		return "user";
	}
	@RequestMapping(value="/enter/admin", method = RequestMethod.GET)
	public String enteradmin() {
		return "admin";
	}
}
