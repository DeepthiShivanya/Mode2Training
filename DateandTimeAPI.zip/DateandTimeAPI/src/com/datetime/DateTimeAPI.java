package com.datetime;

import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.Period;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;

public class DateTimeAPI {
	public static void main(String args[]) {
		DateTimeAPI datetime = new DateTimeAPI();
		datetime.Testcase();

	}

	public void Testcase() {
		LocalDateTime date = LocalDateTime.now();
		System.out.println("localdatetime:" + date);

		LocalDate date2 = date.toLocalDate();
		System.out.println("localdate:" + date2);

		LocalTime time = date.toLocalTime();
		System.out.println("localtime:" + time);

		Month month = date.getMonth();
		int day = date.getDayOfMonth();
		int sec = date.getSecond();
		System.out.println("month:" + month + ",day:" + day + ",sec:" + sec);

		LocalDateTime date3 = date.withDayOfMonth(11).withYear(1997);
		System.out.println(date3);

		LocalDate date4 = LocalDate.of(2014, Month.DECEMBER, 12);
		System.out.println(date4);

		LocalTime time1 = LocalTime.of(9, 15);
		System.out.println(time1);

		LocalTime time2 = LocalTime.parse("10:19:06");
		System.out.println(time2);

		ZonedDateTime zone = ZonedDateTime.parse("2007-12-03T10:15:30+01:00[Europe/Paris]");
		System.out.println(zone);

		ZoneId id = ZoneId.of("Asia/Karachi");
		System.out.println("ZoneId: " + id);

		ZoneId currentZone = ZoneId.systemDefault();
		System.out.println("CurrentZone: " + currentZone);

		LocalDate today = LocalDate.now();
		System.out.println("Current date: " + today);

		LocalDate nextWeek = today.plus(1, ChronoUnit.WEEKS);
		System.out.println("Next week: " + nextWeek);

		LocalDate nextMonth = today.plus(1, ChronoUnit.MONTHS);
		System.out.println("Next month: " + nextMonth);

		LocalDate nextYear = today.plus(1, ChronoUnit.YEARS);
		System.out.println("Next year: " + nextYear);

		LocalDate nextDecade = today.plus(1, ChronoUnit.DECADES);
		System.out.println("Date after ten year: " + nextDecade);

		Period period = Period.between(nextMonth, today);
		System.out.println("Period: " + period);

		LocalTime time3 = LocalTime.now();
		Duration twoHours = Duration.ofHours(2);

		LocalTime time4 = time3.plus(twoHours);
		Duration duration = Duration.between(time3, time4);

		System.out.println("Duration: " + duration);

		LocalDate nextTuesday = today.with(TemporalAdjusters.previous(DayOfWeek.TUESDAY));
		System.out.println("Next Tuesday on : " + nextTuesday);

		
		LocalDate firstInYear = LocalDate.of(today.getYear(), today.getMonth(), 1);
		LocalDate secondSaturday = firstInYear.with(TemporalAdjusters.nextOrSame(DayOfWeek.SATURDAY))
				.with(TemporalAdjusters.next(DayOfWeek.SATURDAY));
		System.out.println("Second Saturday on : " + secondSaturday);
		
		

	}
}
