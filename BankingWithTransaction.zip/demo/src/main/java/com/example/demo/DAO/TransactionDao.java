package com.example.demo.DAO;


import java.util.List;

import org.springframework.boot.autoconfigure.data.web.SpringDataWebProperties.Pageable;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.example.demo.model.Transaction;

public interface TransactionDao extends  PagingAndSortingRepository<Transaction,String>{
	
}
