package com.example.demo.exception;
public class InsufficientBalance extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public InsufficientBalance(String exception){
		super(exception);
	}
}
