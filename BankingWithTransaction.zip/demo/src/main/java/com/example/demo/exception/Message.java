package com.example.demo.exception;

import org.springframework.stereotype.Component;

@Component
public class Message {
	String msg1;
	public Message(){
		
	}
	public Message(String msg1){
		this.msg1=msg1;
	}
	public String getMsg1() {
		return msg1;
	}
	public void setMsg1(String msg1) {
		this.msg1 = msg1;
	}
	
	
}
