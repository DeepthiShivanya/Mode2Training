package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.DAO.AccountDao;
import com.example.demo.model.Account;


@Service
public class AccountService {
	@Autowired 
	AccountDao adao;
	private int accno=100000000;
	private int balance=50000;
	private int cust=100;
	
	//Generating the account number and Adding it along with customer ID
	public String addAccountDetails(Account account){
		account.setCustid(cust++);
		account.setAccnum("SBI"+(accno++));
		//account.setBalance(balance);
		adao.save(account);
		return "Successful created";
	}
}
