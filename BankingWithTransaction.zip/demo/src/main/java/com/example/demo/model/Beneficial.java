package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="Beneficial")
public class Beneficial {
	@Id
	@Column(name="custid")
	private int custid;
	@Column(name="baccno")
	private String baccno;
	@Column(name="ifsc")
	private String ifsc;
	public int getCustid() {
		return custid;
	}
	public void setCustid(int custid) {
		this.custid = custid;
	}
	public String getBaccno() {
		return baccno;
	}
	public void setBaccno(String baccno) {
		this.baccno = baccno;
	}
	public String getIfsc() {
		return ifsc;
	}
	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}
	
		
}
