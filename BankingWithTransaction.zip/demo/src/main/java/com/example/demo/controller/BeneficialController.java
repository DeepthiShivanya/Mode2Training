package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Beneficial;
import com.example.demo.service.BeneficialService;
@RestController
public class BeneficialController {
	@Autowired
	BeneficialService benservice;
	@PostMapping(value="beneficial/add")
	public String addCustomerDetails(@RequestBody Beneficial ben){
		return 	benservice.addBeneficialDetails(ben);
		
	}
	@GetMapping(value="beneficial/get/{ifsc}")
	public List<Beneficial> getById(@PathVariable(value="ifsc") String id){
		List<Beneficial> ben=benservice.getAllDetailsbyIFSC_code(id);
		return ben;
	}
	@GetMapping(value="beneficial/get/{ifsc}/bacc/{baccno}")
	public List<Beneficial> getById(@PathVariable(value="ifsc") String id,@PathVariable(value="baccno")String baccno){
		List<Beneficial> ben=benservice.getAllDetailsbyifscandBaccno(id,baccno);
		return ben;
	}
}
