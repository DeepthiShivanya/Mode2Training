package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.DAO.CustomerDao;
import com.example.demo.dto.CustomerDto;
import com.example.demo.model.Customer;
import com.example.demo.model.Transaction;

@Service
public class CustomerServiceImpl {
	@Autowired
	CustomerDao custDao;
	ModelMapper mapper = new ModelMapper();
	List<CustomerDto> list = new ArrayList<CustomerDto>();
	private int accno = 100000000;
	private int cust = 1;

	// Adding Customer Details only if Age is greater than 21
	public String addCustomerDetails(Customer customer) {
		if (customer.getAge() >= 21) {
			// customer.setAccnum("SBI"+(accno++));
			customer.setEmpId((cust++));
			customer.setPassword("HCL" + customer.getcustId());
			custDao.save(customer);
			return "Successful registered";
		} else {
			return "Age should be greater than 21";
		}

	}

	// Updating with Remaining profile
	public void updateCustomer(int id, Customer customer) {
		Customer customer1 = custDao.findById(id).orElse(null);
		customer1.setJob(customer.getJob());
		customer1.setEmail(customer.getEmail());
		customer1.setPhno(customer.getPhno());
		custDao.save(customer1);
	}

	// Implementing with DTO class
	public List<CustomerDto> getAllCustomers() {
		custDao.findAll().forEach(customer -> convertTo(customer));
		return list;
	}

	private void convertTo(Customer customer) {
		list.add(mapper.map(customer, CustomerDto.class));

	}

	// Implementing Delete method
	public String deleteCustomers(int id) {
		custDao.deleteById(id);
		return "delete Successfully";
	}

	// Finding By customer ID
	public Customer getCustomerById(int id) {
		return custDao.findById(id).orElse(null);

	}

	// Performing Sorting Operation based on age
	public List<Customer> getCustomerDetailbyAge(String sortBy) {
		Sort sortOrder = Sort.by(sortBy);

		List<Customer> list = (List<Customer>) custDao.findAll(sortOrder);

		return list;
	}

}
